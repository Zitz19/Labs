var searchData=
[
  ['map_21',['Map',['../classMap.html#aaf101ae5590de37bf1a164fee8180d07',1,'Map::Map()=default'],['../classMap.html#afb05ef330501467bf970e89960be04ab',1,'Map::Map(const Map&lt; Tk, Tv &gt; &amp;copy)=default']]]
];
